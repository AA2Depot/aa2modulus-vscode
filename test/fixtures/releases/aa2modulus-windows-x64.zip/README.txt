aa2modulus test fixture. Not a real release.
